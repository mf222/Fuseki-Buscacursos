import json
import boolean
import unicodedata
import sys

algebra = boolean.BooleanAlgebra()

def remove_accents(input_str):
    nfkd_form = unicodedata.normalize('NFKD', input_str)
    only_ascii = nfkd_form.encode('ASCII', 'ignore')
    return only_ascii.decode('utf-8')

def to_dnf(st):
    #print(st)
    #print("lalá")
    if st == 'No tiene':
        return ''

    st = remove_accents(st)
    print(st)

    st = st.replace(' y ', '*')
    st = st.replace(' o ', '+')
    st = st.replace('(c)', '_c_')
    st = st.replace(' ', '_expSpace')
    st = st.replace(',', '_expComa_')
    st = st.replace('-', '_expGuion_')
    st = st.replace('>', '_expMayor_')
    st = st.replace('<', '_expMenor_')
    st = st.replace('=', '_expIgual_')
    st = st.replace('/', '_expSlash_')
    #print(st)

    if '*' not in st:
        return st    

    expr = algebra.parse(st)
    dnf_expr = algebra.normalize(expr, expr.OR)
    return str(dnf_expr)

def join():
    new_resp = {}
    new_resp['Horario'] = {}
    new_resp['Profesor'] = {}
    new_resp['Curso'] = {}
    new_resp['Seccion'] = {}
    for ide in range(1, 11):
        path = 'output\\outp%d.json' % ide
        print(path)
        #return
        current = {}
        with open(path) as tf:
            resp = json.load(tf)

        i = 0
        errors = 0
        extra = []
        
        for val in resp.values():
            nrc = val['NRC']
            
            section = {}
            section['VacantesTotales'] = val['Vacantes Totales']
            section['VacantesDisponibles'] = val['Disponibles']
            section['Campus'] = val['Campus']
            section['NRC'] = nrc
            profesores = val['Profesor'].split(',')
            lista = []
            section['Profesor'] = lista
            
            for p in profesores:
                prof = p.strip()
                lista.append(prof)
                if(new_resp['Profesor'].get(prof) is None):
                    dict_prof = {}
                    dict_prof['Nombre'] = prof
                    dict_prof['Secciones'] = []
                    new_resp['Profesor'][prof] = dict_prof
                new_resp['Profesor'][prof]['Secciones'].append(nrc)

            
            horarios = val['Horarios']
            lista_h = []
            section['Horarios'] = lista_h
            for h in horarios:
                rep_h = "{0}{1}-{2}-{3}".format(h['Dia'], h['Modulo'], h['Tipo'], h['Sala'])

                if(new_resp['Horario'].get(rep_h) is None):
                    new_resp['Horario'][rep_h] = h

                lista_h.append(rep_h)

            sigla = val['Sigla']
            section['Numero'] = val['Seccion']
            section['Curso'] = sigla

            

            if(new_resp['Curso'].get(sigla) is None):
                #print(ide,nrc)
                course = {}
                course['Secciones'] = []
                course['Creditos'] = val['Creditos']
                course['Nombre'] = val['Nombre']
                course['Prerequisitos'] = to_dnf(val['Prerequisitos'])
                course['Restricciones'] = to_dnf(val['Restricciones'])
                course['Relaciones'] = to_dnf(val['Relaciones'])
                course['Equivalencias'] = to_dnf(val['Equivalencias'])
                course['Facultad'] = val['Facultad']
                course['Sigla'] = sigla
                new_resp['Curso'][sigla] = course


            new_resp['Curso'][sigla]['Secciones'].append(nrc) 
            new_resp['Seccion'][nrc] = section

            i+=1
        #print(errors)
        #print(extra)

    with open("resp.json", 'w') as fp:
        json.dump(new_resp, fp, sort_keys=True, indent=4)


if __name__ == '__main__':
    join()