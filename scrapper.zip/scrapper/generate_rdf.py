import json

def to_list(st):
    if st == '':
        return []
    st = st.replace('_expSpace', ' ')
    st = st.replace('_expComa_', ',')
    st = st.replace('_expGuion_', '-')
    st = st.replace('_expMayor_', '>')
    st = st.replace('_expMenor_', '<')
    st = st.replace('_expIgual_', '=')
    st = st.replace('_expSlash_', '/')
    st = st.replace('_c_', '')

    ors = st.split('*')
    resp = []
    for o in ors:
        o = o.replace('(', '')
        o = o.replace(')', '')
        con = o.split('+')
        resp.append(con)
    return resp

if __name__ == "__main__":
    resp = {}   
    resource = 'http://cocke.ing.puc.cl/resource'
    blanks = 0
    
    init="""@prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#> .
@prefix xsd: <http://www.w3.org/2001/XMLSchema#> .
@prefix owl: <http://www.w3.org/2002/07/owl#> .
@prefix rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#> .
@prefix xml: <http://www.w3.org/XML/1998/namespace> .
@prefix sesame: <http://www.openrdf.org/schema/sesame#> .
@prefix fn: <http://www.w3.org/2005/xpath-functions#> ."""

    with open("resp.json") as tf:
        resp = json.load(tf)

    with open("datos.ttl", "w",encoding='utf-8') as f:
        f.write(init)
        for curso in resp['Curso'].values():
            f.write('\n\n')
            sigla = curso['Sigla']
            path = '<{0}/course/{1}>'.format(resource,sigla)
            f.write('{0} a Course ;\n'.format(path))
            #write
            f.write('\tinitial "{0}" ;\n'.format(curso['Sigla']))
            #f.write('\tpuc:name_c "{0}" ;\n'.format(curso['Nombre']))
            f.write('\tfaculty "{0}" ;\n'.format(curso['Facultad']))
            

            req = curso['Prerequisitos']
            req_list = to_list(req)
            for num in range(len(req_list)):
                name_blank = 'blank{0}'.format(blanks + num)
                path_blank = '<{0}/white/{1}>'.format(resource, name_blank)
                f.write('\trequires {0} ;\n'.format(path_blank))
                #blanks+=1

            f.write('\tcredits {0} .\n'.format(curso['Creditos']))


            for req_ors in req_list:
                f.write('\n\n')
                name_blank = 'blank{0}'.format(blanks)
                path_blank = '<{0}/white/{1}>'.format(resource, name_blank)
                f.write('{0} a White ;\n'.format(path_blank))
                blanks+=1

                num_i = 0
                tot = len(req_ors)-1
                for req_ands in req_ors:
                    path = '<{0}/Course/{1}>'.format(resource, req_ands)
                    if num_i == tot:
                        f.write('\tand {0} .\n'.format(path))
                    else:
                        f.write('\tand {0} ;\n'.format(path))
                    num_i += 1


        for horario_key in resp['Horario'].keys():
            f.write('\n\n')
            horario = resp['Horario'][horario_key]
            path = '<{0}/schedule/{1}>'.format(resource,horario_key)
            f.write('{0} a Schedule ;\n'.format(path))
            #write
            f.write('\tday "{0}" ;\n'.format(horario['Dia']))
            f.write('\tmodule {0} ;\n'.format(horario['Modulo']))
            f.write('\ttype "{0}" .\n'.format(horario['Tipo']))

        for seccion in resp['Seccion'].values():
            f.write('\n\n')
            path = '<{0}/section/{1}>'.format(resource, seccion['NRC'])
            f.write('{0} a Section ;\n'.format(path))
            #write
            f.write('\tcampus "{0}" ;\n'.format(seccion['Campus']))
            
            path_curso = '<{0}/course/{1}>'.format(resource, seccion['Curso'])
            f.write('\tbelongs_to {0} ;\n'.format(path_curso))


            for hor in seccion['Horarios']:
                path_hor = '<{0}/schedule/{1}>'.format(resource, hor)
                f.write('\tis_imparted {0} ;\n'.format(path_hor))
            

            f.write('\tnumber {0} .\n'.format(seccion['Numero']))

        for profesor in resp['Profesor'].values():
            f.write('\n\n')
            profesor_link = profesor['Nombre'].replace(" ", "_")
            path = '<{0}/professor/{1}>'.format(resource,profesor_link)
            f.write('{0} a Professor ;\n'.format(path))
            #write
            num_i = 0
            tot = len(profesor['Secciones'])-1
            for seccion in profesor['Secciones']:
                path_hor = '<{0}/section/{1}>'.format(resource, seccion)
                if num_i == tot:
                    f.write('\tteaches {0} .\n'.format(path_hor))
                else:
                    f.write('\tteaches {0} ;\n'.format(path_hor))
                num_i += 1

                

            #f.write('\tname_p "{0}" .\n'.format(profesor['Nombre']))





