import logging
import sys
import traceback
import scrapper
import boolean

threads = 10;
input_name = 'unidades.txt'
inputs_path = 'input\inp'
outputs_path = 'output\outp'


def divide(path_in, path_out, num):
    uniqlines = list(open(path_in).readlines())
    chunk_size = -(-len(uniqlines) // num)
    if chunk_size == 0:
        return

    new_lines = chunks(uniqlines, chunk_size)

    i = 1
    for chunk in new_lines:
        with open('%s%d.txt'%(path_out,i),'w') as f:
            for line in chunk:
                f.write('%s'%line)
        i += 1

def chunks(l, n):
    for i in range(0, len(l), n):
        yield l[i:i+n]

def obtain_info(ide):
    
    inp = '%s%d.txt' % (inputs_path, ide)
    outp = '%s%d.json' % (outputs_path, ide)
    scr = scrapper.Scrapper(inp, outp)
    scr.query_all()
    

def divide_input():
    divide(input_name, inputs_path, threads)

def create_files(path_file):
    for i in range(threads):
        path = '%s%d.txt' % (path_file, (i+1))
        created_file = open(path, 'w')
        created_file.close()

def pregenerate():
    create_files(inputs_path)
    create_files(outputs_path)
    divide_input()

def test():
    st = '(Nivel=Magister) o (Nivel=Doctorado) o (Creditos >= 300)'
    st = '(AGL111)'

    st = st.replace(' y ', '*')
    st = st.replace(' o ', '+')
    st = st.replace('(c)', '_c_')
    st = st.replace(' ', '')
    st = st.replace('>', '_expMayor_')
    st = st.replace('<', '_expMenor_')
    st = st.replace('=', '_expIgual_')

    print(st)

    algebra = boolean.BooleanAlgebra()
    expr = algebra.parse(st)
    print(expr)

    dnf_expr = algebra.normalize(expr, expr.OR)
    print(dnf_expr)


if __name__ == '__main__':
    #pregenerate()
    #obtain_info(3)
    # test()

    try:
        arg1 = sys.argv[1]
        if arg1 == 'preg':
            pregenerate()
        elif arg1 == 'run': 
            ide = int(sys.argv[2])
            obtain_info(ide)

    except:
        print('Error en argumentos')
        print(traceback.format_exc())
        input()
        
        
