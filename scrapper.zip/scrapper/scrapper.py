from bs4 import BeautifulSoup
import requests
import logging
import traceback
import json
import html5lib

class Scrapper:

    def __init__(self, inp, outp):
        self.url_base = 'http://buscacursos.uc.cl/'
        self.unidades = []
        self.horarios = []
        self.define_horarios()
        self.path_log = '%s.log' % (outp)
        self.path_unidades = inp
        self.outp = outp
        self.create_log()
        self.define_unidades()

    def create_log(self):
        with open(self.path_log, 'w'):
            pass
        logging.basicConfig(filename=self.path_log, level=logging.INFO)
        logging.info('Log created')

    def define_horarios(self):
        self.horarios = []
        dias = ['L', 'M', 'W', 'J', 'V', 'S']
        for d in dias:
            for i in range(1,9):
                self.horarios.append('%s%d' % (d, i))



    def define_unidades(self):
        with open(self.path_unidades) as f:
            for unidad in f:
                self.unidades.append(unidad.strip())
        #print(self.unidades)

    def query_all(self):
        self.el_json = {}
        #resp = []
        for un in self.unidades:
            for hor in self.horarios:
                print(un, hor)
                logging.info('Consulta a {0}, {1}'.format(un, hor))
                self.query_by_unidad(hor, un)
                #break
            #break
        #print('aaaa')
        #el_json['Listado'] = resp
        with open(self.outp, 'w') as fp:
            json.dump(self.el_json, fp, sort_keys=True, indent=4)

    def query_by_unidad(self, horario, unidad):
        query = ("{0}?cxml_semestre=2016-2&cxml_unidad_academica={1}"
            "&cxml_modulo_{2}={2}").format(self.url_base,unidad, horario)
        #print(query)
        r = requests.get(query)
        url_info = requests.get(query).text.encode('ISO-8859-1')
        url_soup = BeautifulSoup(url_info,'html5lib')



        pares = url_soup.find_all('tr',{'class': 'resultadosRowPar'})
        impares = url_soup.find_all('tr',{'class': 'resultadosRowImpar'})
        fac_soup = url_soup.find('td',{'style': 'text-align:center; font-weight:bold; font-size:16px; color:#FFFFFF; background:#1730A6; padding:2px; margin:2px'})
        if fac_soup is None:
            return
        facultad = fac_soup.text.strip()
        
        num_results = len(pares) + len(impares)
        print('Parseando:', facultad ,num_results)
        
        act = 0
        for i in range(len(impares)):
            print('Current:', facultad , act,"/",num_results)
            self.parse_curso(pares[i], facultad)
            act+=1
            print('Current:', facultad , act,"/",num_results)
            self.parse_curso(impares[i],facultad)
            act+=1

        if num_results % 2 == 1:
            self.parse_curso(pares[len(pares) - 1], facultad)
            print('Current:', facultad , act,"/",num_results)
            

    def parse_curso(self, element, facultad):

        info = element.find_all('td', recursive=False)
        #info = element.contents
        if self.el_json.get(info[0].text.strip()) is not None:
             return
        # print(info[1].text)
        #n = 0
        #for i in info:
        #    print(n, i)
        #    #print(i.get_text())
        #    print("")
        #    n+=1
        #print(len(info))

        #return

        resp = {}
        resp['NRC'] = info[0].text.strip()

        resp['Sigla'] = info[1].text.strip()
        resp['Retiro'] = info[2].text.strip()
        resp['Ingles'] = info[3].text.strip()
        resp['Seccion'] = info[4].text.strip()
        resp['Aprobacion'] = info[5].text.strip()
        resp['Categoria'] = info[6].text.strip()
        resp['Nombre'] = info[7].text.strip()
        resp['Profesor'] = info[8].text.strip()
        resp['Campus'] = info[9].text.strip()
        resp['Creditos'] = info[10].text.strip()
        resp['Vacantes Totales'] = info[11].text.strip()
        resp['Disponibles'] = info[12].text.strip()
        resp['Facultad'] = facultad
        self.parse_horarios(info[14], resp)
        self.get_requisitos(resp['Sigla'], resp)
        #print(resp)
        self.el_json[resp['NRC']] = resp
        logging.info('Asignado {0}, {1}'.format(resp['NRC'], resp['Sigla']))

    def parse_horarios(self, element, dicc):
        info = element.find_all('tr')
        dicc['Horarios'] = []
        for row in info:
            cols = row.find_all('td')
            modulos = self.parse_modulos(cols[0].text.strip(), cols[1].text.strip(), cols[2].text.strip(), dicc)

    def parse_modulos(self, texto, tipo, sala, dicc):
        formated = texto.split(':')
        dias = formated[0].split('-')
        modulos = formated[1].split(',')

        for d in dias:
            for m in modulos:
                aux = {}
                aux['Dia'] = d
                aux['Modulo'] = m
                aux['Tipo'] = tipo
                aux['Sala'] = sala
                dicc['Horarios'].append(aux)

    def get_requisitos(self, curso, dicc):
        query = 'http://catalogo.uc.cl/index.php?tmpl=component&option=com_catalogo&view=requisitos&sigla={0}'.format(curso)
        url_info = requests.get(query).text.encode('utf-8')
        url_soup = BeautifulSoup(url_info,'html.parser')
        info = url_soup.find_all('span')
        dicc['Prerequisitos'] = info[0].text.strip()
        dicc['Relaciones'] = info[1].text.strip()
        dicc['Restricciones'] = info[2].text.strip()
        dicc['Equivalencias'] = info[3].text.strip()